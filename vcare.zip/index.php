<?php
$title = "Home";
include('include/head.php');
include('include/preloader.php');
include('include/header.php');
include('modules/index.php');
include('include/footer.php');