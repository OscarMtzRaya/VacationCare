<?php
$title = "Contact";
include('include/head.php');
include('include/preloader.php');
include('include/header.php');
include('modules/contact.php');
include('include/footer.php');