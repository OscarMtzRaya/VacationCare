<!-- Javascript  -->   

<script src="/admin/assets/plugins/apexcharts/apexcharts.min.js"></script>
        <script src="/admin/assets/pages/analytics-index.init.js"></script>
        <!-- App js -->
        <script src="/admin/assets/js/app.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js" integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI=" crossorigin="anonymous"></script>

    </body>
    <!--end body-->
</html>