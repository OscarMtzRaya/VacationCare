<?php
require_once('include/sesion.php');
include_once('include/head.php');
include_once('include/header.php');
include_once('modules/index.php');
include_once('include/footer.php');
?>